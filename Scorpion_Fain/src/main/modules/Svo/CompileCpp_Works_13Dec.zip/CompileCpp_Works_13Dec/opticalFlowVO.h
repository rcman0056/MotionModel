#ifndef _MYLIB_H_
#define _MYLIB_H_
// a function prototype for a function exported by library:
extern double* opticalFlow(jbyte *);
#endif